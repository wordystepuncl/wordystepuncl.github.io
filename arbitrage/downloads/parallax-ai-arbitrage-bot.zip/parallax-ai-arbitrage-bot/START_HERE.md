# PARALLAX quick start

- [Open the live demo](https://wordystepuncl.github.io/arbitrage/)
- [Download the source ZIP](https://wordystepuncl.github.io/arbitrage/downloads/parallax-ai-arbitrage-bot.zip)
- Open `DEMO.html` for a local preview. If you started from the downloadable source ZIP, run `npm run build` with Node.js 22 or newer to generate it.

The website is served from the shared `wordystepuncl.github.io` repository. See [GitHub Pages setup](docs/GITHUB_PAGES.md) for the publishing instructions.

For GitHub's **About** section, copy `description.txt` into **Description** and enter the lines from `tags.txt` as **Topics**.
